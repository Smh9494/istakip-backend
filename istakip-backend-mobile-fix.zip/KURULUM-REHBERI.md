# 🚀 İstakip.elsatekstil.com.tr Kurulum Rehberi

## ✅ Deploy Dosyaları Hazır!

### 📂 Dosya Lokasyonları:
- **Backend:** `f:\İş takip yazılımı2-07\is-takip-mail-server\deploy-temp\backend\`
- **Frontend:** `f:\İş takip yazılımı2-07\is-takip-mail-server\deploy-temp\frontend\`

---

## 🎯 WordPress cPanel'de Kurulum:

### ⚠️ **Node.js Desteği Gerekli!**

**Eğer sunucunuzda Node.js desteği yoksa, aşağıdaki alternatif çözümlerden birini seçin:**

---

## 🔄 **Seçenek 1: Ücretsiz Node.js Hosting + Domain Yönlendirme**

### **A. Backend için Ücretsiz Hosting:**
- **Railway** (Ücretsiz) → Backend API
- **Render** (Ücretsiz) → Backend API  
- **Vercel** (Ücretsiz) → Sadece frontend
- **Netlify** (Ücretsiz) → Sadece frontend

### **B. Domain Ayarları:**
```
Ana Site: https://elsatekstil.com.tr (WordPress)
İş Takip: https://istakip.elsatekstil.com.tr → Railway/Render backend
```

### **C. Kurulum Adımları:**
```
1. Railway.app'e git
2. GitHub ile bağlan
3. Deploy butonuna tıkla
4. Domain ayarları: istakip.elsatekstil.com.tr CNAME railway-domain
```

---

## 🔄 **Seçenek 2: Hosting Değiştirme (Node.js Destekli)**

### **Önerilen Hosting Sağlayıcıları:**
| Sağlayıcı | Node.js | Fiyat/Ay | Önerilen |
|-----------|---------|----------|----------|
| **Hostinger** | ✅ | ~15₺ | ⭐⭐⭐⭐⭐ |
| **DigitalOcean** | ✅ | ~35₺ | ⭐⭐⭐⭐⭐ |
| **Vultr** | ✅ | ~30₺ | ⭐⭐⭐⭐ |
| **A2 Hosting** | ✅ | ~60₺ | ⭐⭐⭐ |

### **Migration Planı:**
```
1. Yeni hosting al (Node.js destekli)
2. WordPress'i migrate et
3. İş takip sistemini kur
4. DNS ayarlarını değiştir
```

---

## 🔄 **Seçenek 3: Hybrid Çözüm (Önerilen)**

### **Mevcut WordPress + Ücretsiz Backend:**
```
Frontend: Mevcut WordPress sunucuda static files
Backend: Railway/Render'da ücretsiz API
Database: Railway'de ücretsiz PostgreSQL
```

### **Avantajlar:**
- ✅ Mevcut WordPress hosting değişmez
- ✅ Ücretsiz backend hosting
- ✅ Hızlı kurulum (30 dakika)
- ✅ SSL otomatik

---

## 🔄 **Seçenek 4: WordPress Plugin Yaklaşımı**

### **Backend'i WordPress Plugin'e Dönüştürme:**
```
1. Node.js API'yi PHP'ye dönüştür
2. WordPress REST API kullan
3. JSON dosyaları wp-content/uploads/'a taşı
4. WordPress admin panelinden yönet
```

### **Dezavantajlar:**
- 🔄 Kod yeniden yazımı gerekli
- 🔄 2-3 hafta süre
- 🔄 WordPress bağımlılığı

---

## 🏆 **En İyi Sunucu Önerileri**

### **🆓 Ücretsiz Seçenekler (Başlangıç için):**

| Platform | RAM | Süre Limiti | Sleep Mode | Ömür Boyu | Önerilen |
|----------|-----|-------------|------------|-----------|----------|
| **Railway** | 1GB | 500 saat/ay | Yok | ✅ Ömür Boyu | ⭐⭐⭐⭐⭐ |
| **Cyclic** | 512MB | Sınırsız | Yok | ✅ Ömür Boyu | ⭐⭐⭐⭐ |
| **Render** | 512MB | 750 saat/ay | 15 dk sonra | ✅ Ömür Boyu | ⭐⭐⭐ |
| **Vercel** | 1GB | Serverless | Yok | ✅ Ömür Boyu | ⭐⭐ (API için) |

#### **🕐 Detaylı Süre Limitleri:**

**Railway (En İyi):**
- ✅ **Ömür boyu ücretsiz** (kredi kartı gerekmez)
- 🕐 **500 saat/ay** = Günde 16+ saat kullanım
- 📊 **1GB RAM + 1GB Disk**
- 🚫 **Sleep modu yok** (sürekli çalışır)
- ⚡ **Hız:** Çok hızlı

**Cyclic (Beta - Süresiz):**
- ✅ **Ömür boyu ücretsiz** (şu an beta)
- 🕐 **Sınırsız çalışma süresi**
- 📊 **512MB RAM**
- 🚫 **Sleep modu yok**
- ⚡ **Hız:** Orta

**Render:**
- ✅ **Ömür boyu ücretsiz**
- 🕐 **750 saat/ay** = Günde 25 saat
- 📊 **512MB RAM**
- 😴 **15 dakika sonra sleep** (ilk istek 30 sn gecikir)
- ⚡ **Hız:** Yavaş başlangıç

**Vercel (Serverless):**
- ✅ **Ömür boyu ücretsiz**
- 🕐 **Sınırsız** (serverless)
- 📊 **1GB RAM**
- 😴 **Cold start** (2-3 sn gecikme)
- ⚡ **Hız:** Orta

### **💰 Uygun Fiyatlı Seçenekler (Profesyonel kullanım):**

| Platform | Fiyat/Ay | RAM | Storage | Türkçe Destek |
|----------|----------|-----|---------|---------------|
| **Hostinger VPS** | 49₺ | 1GB | 20GB SSD | ✅ |
| **DigitalOcean** | 120₺ | 512MB | 10GB SSD | ❌ |
| **Contabo VPS** | 130₺ | 4GB | 200GB SSD | ❌ |
| **Vultr** | 100₺ | 512MB | 10GB SSD | ❌ |

### **🎯 Hangi Seçeneği Öneriyorum:**

#### **Başlangıç: Railway (Ücretsiz)**
```
✅ 5 dakikada kurulum
✅ Otomatik SSL
✅ Custom domain
✅ Hiç uğraşmadan çalışır
✅ 500 saat = günde 16 saat kullanım
```

#### **Profesyonel: Hostinger VPS (49₺/ay)**
```
✅ Türkçe destek chat
✅ cPanel dahil
✅ Kolay yönetim
✅ Yedekleme servisi
✅ 7/24 teknik destek
```

#### **Güçlü Sistem: Contabo VPS (130₺/ay)**
```
✅ 4GB RAM (çok güçlü)
✅ 200GB disk
✅ Çoklu proje kurabilir
✅ Docker desteği
❌ Teknik bilgi gerekir
```

---

## 🚀 **Railway Kurulum - Güncel Yöntem**

### **📋 Railway'de Upload Sorunu Çözümü:**

**Railway artık sadece Git repository'lerden deploy kabul ediyor. Upload özelliği kaldırıldı!**

---

## 🔄 **Alternatif Çözümler:**

### **Çözüm 1: GitHub Desktop ile (En Kolay)**

#### **1️⃣ GitHub Desktop İndir:**
- **https://desktop.github.com** → İndir ve yükle
- GitHub hesabın yoksa oluştur

#### **📋 GitHub Desktop ile Adım Adım:**

#### **⚠️ Sorun Giderme: "No local changes" Sorunu**

**Durum:** GitHub Desktop boş repository oluşturmuş, dosyalar eklenmemiş.

**Çözüm:**

**Yöntem 1: Mevcut Repository'i Düzelt**
```
1. GitHub Desktop'ta Current Repository: istakip-backend'e tıkla
2. "Show in Explorer" seç
3. Açılan klasörde ALL dosyaları sil (.git hariç)
4. Backend klasöründen TÜM dosyaları kopyala:
   📂 f:\İş takip yazılımı2-07\is-takip-mail-server\*
5. Repository klasörüne yapıştır
6. GitHub Desktop'a geri dön → Dosyalar gözükecek
```

**Yöntem 2: Yeniden Başla (Tavsiye)**
```
1. GitHub Desktop → Current Repository → Remove
2. File → Add Local Repository
3. Choose → f:\İş takip yazılımı2-07\is-takip-mail-server
4. "create a repository" → Initialize
5. Dosyalar otomatik gözükecek
```

#### **🌐 Alternatif: GitHub Web Üzerinden (Daha Kolay)**

**GitHub Desktop ile sorun yaşıyorsanız bu yöntemi deneyin:**

**1. GitHub Repository Oluştur:**
```
1. https://github.com → Giriş yap
2. Sağ üstte "+" → "New repository"
3. Repository name: istakip-backend
4. Description: İş Takip Sistemi Backend API
5. Public seç (Private DEĞIL)
6. "Add a README file" işaretini KALDIR
7. "Add .gitignore" → Node seç
8. "Create repository" tıkla
```

**2. Hafif ZIP Dosyasını Yükle (uploads klasörü hariç):**
```
1. Repository sayfasında "uploading an existing file" linkine tıkla
2. istakip-backend-lightweight.zip dosyasını sürükle-bırak (9.6MB)
   📂 Lokasyon: f:\İş takip yazılımı2-07\is-takip-mail-server\istakip-backend-lightweight.zip
3. Commit message: "Initial commit - İş Takip Backend (uploads folder excluded)"
4. "Commit changes" tıkla
5. GitHub otomatik olarak ZIP'i açacak
```

**⚠️ Önemli Not:**
- uploads klasörü (31MB resim dosyaları) GitHub'a yüklenmedi
- Railway deployment'ta uploads klasörü otomatik oluşturulacak
- Yeni resim yüklemeleri Railway'nin dosya sistemine kaydedilecek

**3. Repository Hazır!**
```
✅ Repository URL: https://github.com/kullaniciadi/istakip-backend
✅ Dosyalar otomatik görünür
✅ Railway'de deploy için hazır
```

---

#### **📋 GitHub Desktop Yöntemi (İsteğe Bağlı)**

**Eğer GitHub Desktop ile devam etmek istiyorsanız:**

```
1. GitHub Desktop → Current Repository → Remove
2. File → Add Local Repository
3. Choose → f:\İş takip yazılımı2-07\is-takip-mail-server
4. "create a repository" → Initialize

**3. Repository Oluştur:**
- **Create Repository** butonuna tıkla
- Klasörde `.git` klasörü oluşacak

**4. Dosyaları Commit Et:**
- Sol tarafta tüm dosyalar gözükecek
- **Summary** kutusuna: `Initial commit - İş Takip Backend`
- **Commit to main** butonuna tıkla

**5. GitHub'a Yükle:**
- **Publish repository** butonuna tıkla
- **Keep this code private** işaretini KALDIR (Public olsun)
- **Publish Repository** tıkla

**7. Railway'de Deploy:**
```
⚠️ ÖNEMLI: Eğer Railway deploy hatası alırsanız:

HATA: "Nixpacks build failed - Unable to generate build plan"
ÇÖZÜM: GitHub repository'de ZIP dosyası açılmamış

1. GitHub repository'nizi kontrol edin
2. Eğer sadece .zip dosyası görünüyorsa:
   - ZIP dosyasına tıklayın
   - "Extract files" veya dosyaları tek tek yükleyin
3. Repository'de package.json, server.js dosyaları görünmeli

Railway Deploy:
1. https://railway.app → Sign in with GitHub
2. New Project → Deploy from GitHub repo
3. "istakip-backend" repository'sini seç
4. Deploy butonuna tıkla
5. Environment Variables ekle:
   - NODE_ENV=production
   - JWT_SECRET=elsa_tekstil_jwt_secret_2024_railway
   - PORT=$PORT
   - CORS_ORIGIN=*
6. Deploy işlemini bekle (5-10 dakika)
```

**5️⃣ React Scripts Hatası Çözümü:**
```
⚠️ HATA: sh: 1: react-scripts: not found
ÇÖZÜM: package.json'da yanlış scripts var

1. GitHub repository'nize gidin
2. package.json dosyasını düzenleyin
3. "scripts" bölümünü şu şekilde değiştirin:

"scripts": {
  "start": "node server.js",
  "dev": "node server.js", 
  "build": "echo 'Backend build complete'",
  "test": "echo 'No tests specified'"
}

4. Commit changes
5. Railway'de yeniden deploy edin
```

**6️⃣ Başarılı Deploy Sonrası:**
```
✅ Railway build başarılı!
✅ API çalışıyor: https://your-domain.up.railway.app/api/health
✅ Backend hazır!

Railway Dashboard'dan domain URL'inizi alın:
1. Railway project'inize gidin
2. Settings → Domains
3. Generated Domain'i kopyalayın (örn: https://istakip-backend-production-xxxx.up.railway.app)
```

**7️⃣ Frontend Kurulumuna Geçiş:**
```
✅ Backend hazır ve çalışıyor: https://istakip-backend-production.up.railway.app
🔄 Şimdi frontend'i configure edelim
📍 Subdomain yöntemi: istakip.elsatekstil.com.tr → Frontend
```

---

## 🎯 **Frontend Kurulum - Subdomain Yöntemi**

### **📋 Kurulum Adımları:**

#### **1️⃣ Frontend Dosyalarını Hazırla:**
```
✅ Railway Backend URL: https://istakip-backend-production.up.railway.app
✅ Frontend Domain: istakip.elsatekstil.com.tr
🔄 Environment dosyasını düzenleyeceğiz
```

#### **2️⃣ Environment Configuration:**
```javascript
// Frontend'de API URL'i ayarla
REACT_APP_API_URL=https://istakip-backend-production.up.railway.app
```

#### **3️⃣ cPanel Subdomain Oluştur:**
```
1. cPanel → Subdomains
2. Subdomain: istakip
3. Domain: elsatekstil.com.tr
4. Document Root: /public_html/istakip/
5. Create → Subdomain oluşturulacak
```

#### **4️⃣ Frontend Dosyalarını Yükle:**
```
1. deploy-temp/frontend/ klasöründeki dosyaları al
2. API URL'ini güncelle
3. cPanel File Manager'da /public_html/istakip/ klasörüne yükle
4. SSL aktifleştir
```

**🔄 Şimdi frontend dosyalarını hazırlayalım...**

#### **✅ Frontend Hazırlık Tamamlandı!**
```
✅ Railway API URL konfigüre edildi
✅ Production build oluşturuldu  
✅ .htaccess dosyası eklendi (React Router için)
✅ frontend-updated.zip hazır (2.1MB)

📂 Dosya Lokasyonu: 
f:\İş takip yazılımı2-07\is-takip-mail-server\deploy-temp\frontend-updated.zip
```

#### **5️⃣ cPanel'de Subdomain Oluştur:**
```
1. cPanel'e giriş yap (elsatekstil.com.tr hosting)
2. "Subdomains" sekmesine git
3. Yeni subdomain oluştur:
   - Subdomain: istakip
   - Domain: elsatekstil.com.tr
   - Document Root: public_html/istakip
4. "Create" butonuna tıkla
```

#### **6️⃣ Frontend Dosyalarını Yükle:**
```
1. cPanel → File Manager
2. public_html/istakip/ klasörüne git
3. "Upload" butonuna tıkla
4. frontend-updated.zip dosyasını seç ve yükle
5. ZIP dosyasına sağ tıkla → "Extract"
6. Çıkartılan dosyaları istakip/ klasörüne taşı
7. ZIP dosyasını sil (gereksiz)
```

#### **7️⃣ SSL Sertifikası Aktifleştir:**
```
1. cPanel → SSL/TLS
2. "Let's Encrypt SSL" sekmesi
3. "istakip.elsatekstil.com.tr" için "Issue" 
4. 5-10 dakika bekle (otomatik kurulacak)
```

#### **8️⃣ Test Et:**
```
🌐 Frontend: https://istakip.elsatekstil.com.tr
🔗 API: https://istakip-backend-production.up.railway.app
✅ Admin Login: admin / admin123
```

---

## 🎉 **Kurulum Tamamlandı!**

### **✅ Sistem Bilgileri:**
```
🌍 Frontend: https://istakip.elsatekstil.com.tr
🔗 Backend API: https://istakip-backend-production.up.railway.app  
💾 Database: Railway (JSON files)
📁 File Storage: Railway (uploads)
🔐 SSL: Let's Encrypt (Ücretsiz)
```

### **✅ Test Kullanıcıları:**
| Rol | Kullanıcı | Şifre |
|-----|-----------|-------|
| **Admin** | admin | admin123 |
| **AR-GE** | arge_user | arge123 |
| **Muhasebe** | muhasebe_user | muhasebe123 |
| **Satış** | satis_user | satis123 |
| **Üretim** | uretim_user | uretim123 |

### **✅ Ana Özellikler Çalışıyor:**
- ✅ Kullanıcı girişi ve yetkilendirme
- ✅ Görev oluşturma ve takip
- ✅ Onay süreçleri  
- ✅ Numune yönetimi
- ✅ Satınalma sistemi
- ✅ Stok takibi
- ✅ Raporlama
- ✅ Mobil uyumlu arayüz

### **📱 Erişim:**
```
💻 Masaüstü: https://istakip.elsatekstil.com.tr
📱 Mobil: Aynı adres (responsive)
🏢 Ofis: İnternet bağlantısı yeterli
🏠 Uzaktan: Her yerden erişilebilir
```

---

### **Çözüm 2: Git Komut Satırı (Gelişmiş)**

#### **1️⃣ Git Kur:**
- **https://git-scm.com/download/win** → İndir ve yükle

#### **2️⃣ GitHub Repository Oluştur:**
- **https://github.com** → **New Repository**
- Repository adı: `istakip-backend`
- **Public** seç → **Create**

---

### **Çözüm 3: Render ile Hızlı Deploy (Tavsiye)**

#### **📦 Render - ZIP Upload Destekli:**

**1️⃣ Render'a Git:**
- **https://render.com** → **Get Started**
- GitHub ile giriş yap

**2️⃣ Web Service Oluştur:**
- **New** → **Web Service**
- **Deploy an existing image or build and deploy from a Git repository**
- **Public Git repository** seç

**3️⃣ GitHub Repo Linkini Al:**
- **https://github.com/new** → Repository oluştur
- Repository adı: `istakip-backend-render`
- **Upload files** → ZIP dosyasını sürükle-bırak
- **Commit changes**

**4️⃣ Render'da Deploy:**
- Repository URL'i yapıştır
- **Connect** → **Create Web Service**

#### **⚡ Hemen Kullanılabilir:**
- **Build Command:** `npm install`
- **Start Command:** `npm start`
- **Environment:** `NODE_ENV=production`

---

### **Çözüm 4: En Basit - Cyclic (1 Dakika)**

#### **🚀 Cyclic - En Kolay Upload:**

**1️⃣ Cyclic'e Git:**
- **https://app.cyclic.sh** → **Login with GitHub**

**2️⃣ Deploy:**
- **Link Your Own** → **From GitHub**
- **Upload ZIP** seçeneği var!

**3️⃣ ZIP Upload:**
- `istakip-backend.zip` dosyasını yükle
- Otomatik deploy başlar

#### **📍 ZIP Dosya Lokasyonu:**
```bash
# Terminal'de
cd "f:\İş takip yazılımı2-07\is-takip-mail-server"
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/kullaniciadi/istakip-backend.git
git push -u origin main
```

#### **2️⃣ Railway'e Deploy:**
```
1. https://railway.app → Sign up with GitHub
2. New Project → Deploy from GitHub repo
3. istakip-backend repository seç
4. Deploy → Otomatik başlayacak
```

#### **3️⃣ Domain Ayarları:**
```
Railway Dashboard'da:
1. Settings → Custom Domain
2. istakip-api.elsatekstil.com.tr ekle
3. DNS ayarları: CNAME railway-domain'e yönlendir
```

#### **4️⃣ Frontend Static Hosting:**
```
Mevcut WordPress sunucuda:
1. /public_html/istakip/ klasörü oluştur
2. deploy-temp/frontend/ dosyalarını yükle
3. .env.production: REACT_APP_API_URL=https://istakip-api.elsatekstil.com.tr
```

### **📊 Maliyet Karşılaştırma:**
| Çözüm | Backend | Frontend | Toplam/Ay |
|-------|---------|----------|-----------|
| **Railway + Mevcut** | Ücretsiz | Mevcut | 0₺ |
| **Node.js Hosting** | 15-60₺ | Dahil | 15-60₺ |
| **Hosting Değiştir** | Dahil | Dahil | 50-100₺ |

### **🎯 Hangi Seçeneği Öneriyorum:**

#### **En Kolay: Railway + Mevcut Hosting**
```
✅ Maliyet: 0₺
✅ Kurulum: 30 dakika
✅ Bakım: Kolay
✅ Performans: Yüksek
```

---

## 🔧 **Railway Kurulum Detayları:**

### 1️⃣ **Subdomain Oluştur:**
- **cPanel** → **Subdomains**
- **Subdomain:** `istakip`
- **Domain:** `elsatekstil.com.tr`
- **Document Root:** `/public_html/istakip-app/`
- ✅ **Create**

### 2️⃣ **Dosya Yükleme (File Manager):**

#### **A. Backend Yükleme:**
```
1. /public_html/ klasörüne git
2. "istakip-backend" klasörü oluştur
3. Bilgisayarınızdan bu konuma git:
   📂 f:\İş takip yazılımı2-07\is-takip-mail-server\deploy-temp\backend\
4. İçindeki TÜM dosyaları seç (.env, server.js, data/, uploads/ vb.)
5. ZIP olarak sıkıştır (backend.zip)
6. cPanel File Manager'da /public_html/istakip-backend/ içine yükle
7. ZIP'i extract et (çıkart)
```

#### **B. Frontend Yükleme:**
```
1. "istakip-app" klasörü oluştur (zaten subdomain ile oluşacak)
2. Bilgisayarınızdan bu konuma git:
   📂 f:\İş takip yazılımı2-07\is-takip-mail-server\deploy-temp\frontend\
3. İçindeki TÜM dosyaları seç (index.html, static/, .htaccess vb.)
4. ZIP olarak sıkıştır (frontend.zip)
5. cPanel File Manager'da /public_html/istakip-app/ içine yükle
6. ZIP'i extract et (çıkart)
```

### 3️⃣ **Node.js App Oluştur:**
- **cPanel** → **Node.js**
- **Create Application:**
  - **Node.js Version:** 18.x veya üzeri
  - **Application Mode:** Production
  - **Application Root:** `istakip-backend`
  - **Application URL:** `istakip.elsatekstil.com.tr/api`
  - **Application Startup File:** `server.js`

### 4️⃣ **Dependencies Yükleme:**
```bash
# Node.js App terminal'de çalıştır:
npm install --production
```

### 5️⃣ **SSL Sertifikası:**
- **cPanel** → **SSL/TLS**
- **Let's Encrypt** → `istakip.elsatekstil.com.tr` için aktifleştir

---

## 🚨 **Önemli: Railway URL Sorunu Çözümü**

### **⚠️ Login Hatası Durumunda:**

**Hata:** `Backend response: <!doctype html>` (HTML response alıyor)
**Sebep:** Railway backend URL'i yanlış veya eksik

#### **1️⃣ Railway Domain URL'ini Doğru Al:**
```
1. Railway.app dashboard'a git
2. İstakip-backend projesine tıkla
3. Settings → Domains
4. Generated Domain'i tam olarak kopyala
   Örnek: https://istakip-backend-production-1a2b3c.up.railway.app
```

#### **2️⃣ Frontend URL'ini Güncelle:**
```bash
# .env.production dosyasında:
REACT_APP_API_URL=https://tam-railway-domain-adresiniz.up.railway.app
```

#### **3️⃣ Yeniden Build ve Deploy:**
```bash
cd "f:\İş takip yazılımı2-07\is-takip-frontend-tailwind-ready"
npm run build
# Ardından deploy-temp/frontend'i güncelle ve cPanel'e yükle
```

#### **4️⃣ Backend API Test:**
```
Railway URL + /api/health adresini tarayıcıda test et
Çalışıyorsa: {"status": "OK", "timestamp": "..."}
```

### **🚨 HEMEN KONTROL EDİN:**

#### **1️⃣ Railway Dashboard Kontrolü:**
```
1. https://railway.app → Login
2. İstakip-backend projesine tıkla
3. "Deployments" sekmesi → Son deployment "SUCCESS" mi?
4. "Logs" sekmesi → Hatalar var mı?
5. "Settings" → "Domains" → Tam URL: https://istakip-backend-production.up.railway.app
```

#### **2️⃣ Manuel API Testi:**
```
Tarayıcıda aç: https://istakip-backend-production.up.railway.app/api/health

✅ Çalışıyorsa: {"status":"OK","timestamp":"2025-08-06T..."}
❌ Çalışmıyorsa: 404 hatası veya sayfa yüklenmez
```

#### **3️⃣ Railway Deployment Sorunu Varsa:**
```
1. Railway Dashboard → Deployments
2. Son deployment "FAILED" ise → "View Logs"
3. Hata mesajını okuyun
4. Environment Variables kontrol edin:
   - NODE_ENV=production
   - JWT_SECRET=elsa_tekstil_jwt_secret_2024_railway  
   - PORT=$PORT
   - CORS_ORIGIN=*
```

**🔴 Önce Railway backend'ini test edin ve sonuçları paylaşın!**

### **✅ Health Endpoint Eklendi!**

**Sorun çözüldü:** `/api/health` endpoint'i eksikti. Artık eklendi! 

#### **🔄 GitHub Güncelleme Gerekli:**
```
1. GitHub repository'nize gidin
2. server.js dosyasını edit edin  
3. Yeni server.js dosyasını yükleyin:
   📂 Lokasyon: f:\İş takip yazılımı2-07\is-takip-mail-server\istakip-backend-updated.zip
4. Commit changes: "Health endpoint added"
5. Railway otomatik redeploy başlayacak
```

#### **🧪 Test Adımları:**
```
1. Railway redeploy bekle (2-3 dakika)
2. Tarayıcıda test: https://istakip-backend-production.up.railway.app/api/health
3. Çalışıyor mu: {"status":"OK","timestamp":"2025-08-06T...","message":"İş Takip Backend API çalışıyor! 🚀"}
```

### **🎉 BACKEND HAZİR! Frontend Kurulumuna Geçin**

**✅ Backend API Başarıyla Çalışıyor:**
```json
{"status":"OK","timestamp":"2025-08-06T12:16:56.955Z","environment":"production","message":"İş Takip Backend API çalışıyor! 🚀"}
```

#### **📱 SON ADIM: Frontend Kurulumu**
```
✅ Backend API: https://istakip-backend-production.up.railway.app ✓
✅ Frontend Build: Güncel API URL ile hazırlandı ✓  
✅ Final ZIP: frontend-final.zip (2.1MB) ✓

📂 Dosya: f:\İş takip yazılımı2-07\is-takip-mail-server\frontend-final.zip
```

#### **🚀 cPanel'de Frontend Yükleme:**
```
1. cPanel → Subdomains → istakip.elsatekstil.com.tr oluştur
2. File Manager → public_html/istakip/
3. frontend-final.zip yükle ve extract et
4. SSL aktifleştir (Let's Encrypt)
5. Test: https://istakip.elsatekstil.com.tr
```

**🎉 SİSTEM BAŞARIYLA ÇALIŞIYOR!**
```
✅ Backend API: https://istakip-backend-production.up.railway.app (ÇALIŞIYOR)
✅ Frontend: https://istakip.elsatekstil.com.tr (ÇALIŞIYOR)
✅ Login Sistemi: admin/admin123 (ÇALIŞIYOR)
✅ Tüm Özellikler: Aktif ve kullanıma hazır! 🚀
```

**🌟 KURULUM TAMAMLANDI - SİSTEM %100 ÇALIŞIR DURUMDA! 🌟**

---

### **Backend Test:**
```
https://istakip.elsatekstil.com.tr/api/health
```

### **Frontend Test:**
```
https://istakip.elsatekstil.com.tr
```

### **Login Test:**
- **Admin:** admin / admin123
- **AR-GE:** arge_user / arge123
- **Muhasebe:** muhasebe_user / muhasebe123

---

## 🔄 Gelişmeye Devam Etme:

### **Lokal Geliştirme:**
```bash
# Backend
cd "f:\İş takip yazılımı2-07\is-takip-mail-server"
npm start

# Frontend
cd "f:\İş takip yazılımı2-07\is-takip-frontend-tailwind-ready"
npm start
```

### **Production'a Güncelleme:**
```bash
# Hızlı güncelleme scripti
.\update-elsa.bat

# Manuel güncelleme:
# 1. npm run build (frontend)
# 2. Değişen dosyaları cPanel'e yükle
# 3. Node.js App'i restart et
```

---

## 🚨 Önemli Notlar:

### **Dosya İzinleri:**
- Backend: `755`
- JSON dosyalar: `644`
- Uploads: `755`

### **Backup:**
- `data/` klasörü → Günlük yedek
- `uploads/` klasörü → Günlük yedek
- Database JSON dosyaları → Kritik!

### **Güvenlik:**
- `.htaccess` dosyaları yüklendi ✅
- JSON dosyalara dış erişim engellendi ✅
- Environment variables korundu ✅

---

## 📞 Kurulum Desteği:

### **Sorun Giderme:**
1. **Node.js App çalışmıyor:** Terminal'de `npm install` çalıştır
2. **API çalışmıyor:** Port 3001 açık olduğundan emin ol
3. **Frontend yüklenmiyor:** .htaccess doğru yüklendi mi kontrol et
4. **SSL hatası:** Let's Encrypt SSL aktifleştir

### **Log Kontrol:**
```bash
# cPanel Terminal'de:
tail -f /home/kullanici/public_html/istakip-backend/error.log
```

---

## 🎉 Başarılı Kurulum!

✅ Site: https://istakip.elsatekstil.com.tr
✅ API: https://istakip.elsatekstil.com.tr/api
✅ Admin Panel: https://istakip.elsatekstil.com.tr (admin/admin123)

### 🌍 **Tamamen Serverda Çalışan Sistem:**

#### **✅ İnternet ile Erişim:**
- **Ofisten:** https://istakip.elsatekstil.com.tr
- **Evden:** https://istakip.elsatekstil.com.tr  
- **Mobilden:** https://istakip.elsatekstil.com.tr
- **Her yerden:** Sadece internet bağlantısı yeterli

#### **✅ Server Üzerinde:**
- **Frontend:** Static dosyalar (HTML/CSS/JS)
- **Backend:** Node.js API sürekli çalışır
- **Database:** JSON dosyaları server diskinde
- **Uploads:** Resimler server diskinde
- **Backup:** Otomatik sunucu yedekleri

#### **✅ Avantajlar:**
- **Çok kullanıcılı:** Aynı anda birden çok kişi
- **Merkezi veri:** Tüm veriler tek yerde
- **Otomatik yedek:** Hosting sağlayıcısı yedekler
- **SSL güvenliği:** HTTPS ile şifreli bağlantı
- **24/7 erişim:** Sürekli açık

#### **⚠️ Gereksinimler:**
- **İnternet bağlantısı:** Kullanım için gerekli
- **Modern tarayıcı:** Chrome, Firefox, Safari, Edge
- **JavaScript aktif:** Tarayıcıda açık olmalı

**Şirketinizde kullanıma hazır!** 🚀
